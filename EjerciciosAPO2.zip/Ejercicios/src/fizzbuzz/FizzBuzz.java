package fizzbuzz;
import java.util.Scanner;
public class FizzBuzz {
public static void main(String[] args) {
	
Scanner miLector = new Scanner (System.in);
	int numeroentero;
	System.out.println("Ingrese un número: ");
	numeroentero=miLector.nextInt();
	
	if (numeroentero%5==0 && numeroentero%3==0) {
		System.out.println("FizzBuzz");
	}
	else if(numeroentero%5==0) {
		System.out.println("Fizz");
	}
	else if (numeroentero%3==0)
	{	
	System.out.println("Buzz");
	}
	
	}
}

