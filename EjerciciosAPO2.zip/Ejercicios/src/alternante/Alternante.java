package alternante;
import java.util.Scanner;

public class Alternante {

    public static void main(String[] args) {

        Scanner miLector = new Scanner(System.in);

        System.out.print("Ingrese el número de términos: ");
        int numTerminos = miLector.nextInt();

        for (int i = 1; i <= numTerminos; i++) {
            if (i % 2 == 0) {
                System.out.print("-" + i + ",");
            } else {
                System.out.print(i + ",");
            }
        }
      
    }
}